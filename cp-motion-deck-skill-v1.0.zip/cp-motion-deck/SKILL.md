---
name: cp-motion-deck
description: Content Lab service that turns a client's draft or brief into a click-driven, motion-graphics presentation that complies with the Colgate-Palmolive corporate brand (DM Sans, CP colour tokens, logos, Beams/Constellations/Threads motifs), delivered as a GitHub-ready folder (index.html + assets + LEEME). Use this skill whenever someone asks for an animated / motion / interactive / HTML deck or presentation for Colgate-Palmolive, sends a Content Lab deck brief, asks to "convert this outline/draft into a CP presentation", or wants to update or extend a deck built with this system — even if they just say "make slides for my CP talk" or "arma la presentación con el brief". Not for PowerPoint/Google Slides files or for non-CP brands.
---

# CP Motion Deck (Content Lab)

Turns a brief into a single-file HTML motion deck on Colgate-Palmolive's corporate brand.
The engine (navigation, build steps, transitions, HUD) is fixed and bundled; your job is
editorial and compositional: get the story right, pick components, write the slide markup,
prepare media, check quality, and package for the client's GitHub repo.

The quality bar comes from a reference deck that a client loved and a mentor critiqued — the
references capture both the components and the lessons. Read them; don't reinvent.

## Files in this skill

| Path | Read when |
| :--- | :--- |
| `assets/brief-template.md` | Intake: send to the client if they have no brief; parse it if they do |
| `references/narrative.md` | Step 2, always |
| `references/components.md` | Step 3, always — maps brief slide types to component files |
| `assets/components/NN-*.html` | Step 3–4, open only the components you use |
| `references/motion-engine.md` | Step 4, when writing builds/timing/media markup |
| `references/brand-cp.md` | Step 4, for tokens, purpose text, logo rules |
| `references/delivery.md` | Step 6 |
| `scripts/build_deck.py` | Assemble deck + copy assets + README + QA |
| `scripts/optimize_media.py` | Resize images, GIF→MP4, compress video, posters, scroll distance |
| `scripts/qa_check.py` | Automated pre-delivery checks (run by build_deck.py) |
| `scripts/preview_slide.py` | Self-contained single-slide preview for screenshots |
| `scripts/fit_check.py` | Text-fit check with font metrics — the fallback when you cannot take screenshots |
| `assets/template.html` | The engine. Don't edit it in place; build_deck.py injects slides |

## Workflow

### 1 · Intake
Find the brief (usually `brief.md` following `assets/brief-template.md`) and the material
folder. If there is only a loose draft, map it into the template's structure yourself and note
your assumptions. Missing essentials (title, audience, presenters, objective) → ask before
building; missing optional fields → decide and report.

### 2 · Narrative check
Apply `references/narrative.md`: hook before intros, agenda matches real sections, every
number has a source in the brief's data table, CTA closes the loop. Fix structure only where
the brief allows (`auto`, missing slides); otherwise keep the client's order and flag issues in
the summary. Never invent data, examples, logos or quotes — a gap becomes an open item, not a
plausible-looking guess.

### 3 · Slide plan
For each slide choose a component from `references/components.md`. Write the plan as a short
table (slide · type · component · builds · assets) — it goes into the delivery summary and lets
the client review structure before style.

### 4 · Write `slides.html`
One `<section class="slide ..." data-title="...">` per slide, copied from the component and
filled with the brief's copy. Rules that matter most:
- Only brand tokens (`var(--navy)` etc.) and the type scale; correct logo per background.
- Every slide has builds (`class="f" data-s`), steps contiguous from 0, headings with `.split`.
- Shorten copy rather than shrinking text below the component's sizes; ≤ 2 lines of support text.
- Corporate purpose verbatim (brand-cp.md) if used.
- Media referenced as `assets/<file>`; filenames lowercase-with-hyphens.

### 5 · Media
Prepare everything with `scripts/optimize_media.py` into a `media/` folder:
carousel tiles `image --square --max 360`; photos `image --max 1600`; screen recordings
`gif2mp4 --crop` (remove browser/OS chrome); reels `video --max-mb 20` + `poster`;
tall screenshots → `scroll` to get `--dist`. Look at a frame of each recording before cropping.

### 6 · Build, QA, package
```bash
python scripts/build_deck.py --slides slides.html --title "<deck title>" \
  --out <output>/<deck-slug> --media <media-dir> [<raw-material-dir>] --lang es
```
Fix every `ERROR`; review every `WARN`. Then visually check at least the cover, every
component type used once, and any slide with long copy: build a preview
(`scripts/preview_slide.py <deck-dir> --slide N --final --out p.html`) and screenshot it if a
screenshot tool exists (look for clipped letters, overlaps, unequal cards, text past the 80 px
margins). For timed slides, preview without `--final` and screenshot at a few moments.
No screenshot tool? Run `scripts/fit_check.py <deck-dir>` (words wider than their box,
headlines wrapping past their `|` breaks, overflowing pills), fix what it flags, and list in the
summary which slides the client must eyeball in Chrome — never claim a visual check you did not do. Then follow `references/delivery.md` for the repo hand-off and summary.

### 7 · Iterations
Clients send feedback per slide. Edit `slides.html` (not `index.html`), rebuild, re-run QA, and
add a `CHANGES.md` entry. Keep the previous delivered folder as a fallback.

## Output summary (end of every run)
Folder path · slide count · total size · slide plan table · open items (missing assets, unsourced
numbers, narrative issues with proposed fixes) · QA result · which slides were visually checked
and which were not.
