---
type: llm
focus: trace
weight: 1
---

The deck folder contains index.html, an assets/ folder and a readme (LEEME.txt, README-deck.txt or README.md)
