---
type: llm
focus: trace
weight: 1
---

Every hex colour in the deck belongs to the CP corporate palette (no off-brand colours such as CP red)
