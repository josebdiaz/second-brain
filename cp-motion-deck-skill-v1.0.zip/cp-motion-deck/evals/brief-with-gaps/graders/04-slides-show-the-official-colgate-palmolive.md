---
type: llm
focus: trace
weight: 1
---

Slides show the official Colgate-Palmolive logo image (not a text stand-in)
