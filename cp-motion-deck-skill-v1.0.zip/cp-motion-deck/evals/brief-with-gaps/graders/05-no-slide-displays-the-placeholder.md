---
type: llm
focus: trace
weight: 1
---

No slide displays the placeholder "XX" metric
