---
type: llm
focus: trace
weight: 1
---

The shipped deck does not reference the missing screenshots captura-cms.png / captura-jira.png
