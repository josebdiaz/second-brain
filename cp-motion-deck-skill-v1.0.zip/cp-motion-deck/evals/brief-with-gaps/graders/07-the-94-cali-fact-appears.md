---
type: llm
focus: trace
weight: 1
---

The 94% Cali fact appears in the deck
