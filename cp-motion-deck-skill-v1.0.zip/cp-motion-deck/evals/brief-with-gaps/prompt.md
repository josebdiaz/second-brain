---
tags: [skill-creator]
max_turns: 60
timeout_seconds: 1800
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Te paso el brief del onboarding de BEX (brief.md) y lo que tengo de material en material/. Hazme el deck animado para subirlo a GitHub; el onboarding es la próxima semana.

Input files: brief.md, material/
