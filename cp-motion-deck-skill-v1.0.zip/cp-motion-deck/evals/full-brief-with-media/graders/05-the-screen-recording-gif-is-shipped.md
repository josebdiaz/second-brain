---
type: llm
focus: trace
weight: 1
---

The screen-recording GIF is shipped as an MP4 video, not as a GIF
