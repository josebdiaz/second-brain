---
type: llm
focus: trace
weight: 1
---

Each carousel piece image is 150 KB or smaller
