---
type: llm
focus: trace
weight: 1
---

The deck shows every brief metric: 4,8, 600+, 70+, ~40 and #3
