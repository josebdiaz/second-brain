---
tags: [skill-creator]
max_turns: 60
timeout_seconds: 1800
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Aquí está el brief del Town Hall de marketing (brief.md) y la carpeta material/ con las piezas, la grabación de Tu Hogar y la captura del sitio. Arma el motion deck con la marca corporativa de CP y déjalo listo para subir al repo de GitHub.

Input files: brief.md, material/
