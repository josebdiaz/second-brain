---
type: llm
focus: trace
weight: 1
---

The CP purpose statement appears verbatim in English
