---
type: llm
focus: trace
weight: 1
---

The unconfirmed ~20% water figure is not displayed on any slide
