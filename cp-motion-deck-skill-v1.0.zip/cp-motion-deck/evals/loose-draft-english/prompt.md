---
tags: [skill-creator]
max_turns: 60
timeout_seconds: 1800
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

hey! Maria from EHS sent me her notes for the Sustainability Week kickoff (draft.md). can you turn them into one of those animated CP decks like the Icesi one? she wants it in english. no assets yet.

Input files: draft.md
