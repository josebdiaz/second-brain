# Colgate-Palmolive corporate brand (condensed for motion decks)

## Purpose (verbatim — never paraphrase, never edit)
- EN: "We are Colgate-Palmolive, a caring, innovative growth company that is reimagining a
  healthier future for all people, their pets and our planet."
- ES: "Somos Colgate-Palmolive, una compañía de cuidado, innovación y crecimiento,
  reimaginando un futuro más saludable para todas las personas, sus mascotas y nuestro planeta."

## Voice
Caring, innovative, growth-oriented, purpose-driven, clear and efficient. Slides reinforce
narration — they are not documents. Sentence case for titles; UPPERCASE only for kickers.
No hype, no jargon walls, no paragraphs longer than 2 lines on a slide.
Write "Content Lab" in full — never the acronym "CLab".

## Colour tokens (the only colours allowed)
| Token | Hex | Use |
| :--- | :--- | :--- |
| `--navy` | #002A46 | Primary; dark backgrounds, headings on light |
| `--deep` | #004272 | Secondary surfaces on navy, deep accents |
| `--blue` | #0068FF | Accent, CTAs, highlights, key metrics |
| `--white` | #FFFFFF | Canvas |
| `--surface` / `--surface2` | #EDF2F7 / #DDE9F0 | Raised cards, tracks |
| `--ink` | #231F20 | Body text on light (never pure black) |
| `--green` | #00C68B | Positive results, growth |
| `--coral` | #FF4C4C | Alerts, contrast marks (≠), REC dots |
| `--mint` | #AAE3CD | Dividers, badges, accents on navy |
| `--sky` | #ABC2DB | Secondary text on navy, outlines |
| `--sand` | #E5CFBF | Warm dividers, human topics |
Do not put mint or sky text on white; do not put blue body text on navy.

## Type
DM Sans 400/500/600/700 (Google Fonts, Arial fallback). Display 72–220 px, H3 40–48 px, body
24–36 px on the 1080 stage, nothing under 14 px. No serif, no faux bold, no all-caps paragraphs.

## Logo
`assets/cp-logo-white.png` on navy/blue; `assets/cp-logo-color.png` on light backgrounds.
Footer position (80, 984), 40 px high; cover header (80, 70), 88 px high. Never stretch, rotate,
recolour or add effects; keep ≥ 32 px clear space.

## Brand motifs (drawn as vector/CSS in the components — no image files needed)
- **Beams**: rounded bars at 135° anchored on a circle (cover, statement).
- **Constellations**: bursts, rings, concentric circles in a 3×4 grid (mint divider).
- **Threads**: interlocking half-circle ribbons in navy/white/coral with fine line echoes (sand divider).
Use motifs on covers and dividers only, sparingly — never as filler behind content.

## Layout
80 px margins, 1760 px content, 8 pt grid (4/8/16/24/32/40/48/56/64/80), card radius 16 px,
pills fully rounded, flat style (only the soft ambient shadow for raised mockups).
