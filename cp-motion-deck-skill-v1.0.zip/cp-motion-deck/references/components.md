# Component catalog

Every component is a working `<section class="slide">` from the reference deck, in
`assets/components/NN-name.html`. Copy the file, then replace the content. Keep the
structure, classes and coordinates unless the new copy forces a change — they already sit on
the 80 px margins / 8 pt grid and have passed visual QA.

The reference copy is Spanish and about the Icesi talk; **never ship it**. Every word,
number and name must come from the client's brief.

## Brief type → component

| Brief `Tipo` | Component file(s) | Use it for | Builds |
| :--- | :--- | :--- | :--- |
| `cover` | `01-cover` | Title, subtitle, event kicker, 3 topic orbs on brand beams, presenters line | orbs 1→3, presenters |
| `hook` | `02-hook-question` | Opening question + a visual that "auto-generates" (browser mock) | title auto; support line on click |
| `speakers` | `03-speakers-2` | 2 presenters, symmetric cards (photo, name, role, studies, pill), "from → to" line. One presenter: keep one card and centre it (`left:536px`). Three: use 555 px cards at left 80 / 683 / 1286 | card 1, card 2, journey line |
| `statement` | `04-purpose-reading` | A sentence that must be read in full (mission, purpose, manifesto). Underlines + orbs fire at reading pace | single step, timed (see motion-engine.md §Reading pace) |
| `agenda` | `05-agenda-3` | 3 blocks with icon, keyword, qualifier, one-line description | panel 1→3 |
| `divider` | `06-divider-network` (blue, animated network + marquee), `10-divider-constellation` (mint, CP constellation motif), `13-divider-globe` (navy, rotating dot globe), `17-divider-threads` (sand, CP threads motif, seamless loop), `21-divider-converge` (blue, three converging rings) | Section openers: index number, title, one-line subtitle, optional presenter pill | single step |
| `comparison` | `07-equation-orbs` (A + B = C), `08-versus-list` (two lists with "vs"), `09-contrast-orbs` (A ≠ B) | Contrasts, formulas, before/after | one element per click |
| `process` | `11-cycle-progress` | A cycle of 3–5 stages around a centre; arc advances, next stage pops when the arc reaches it | stage per click |
| `quote` | `12-quote-highlight` | One big line with two highlighted fragments, plus a supporting line | highlight 1, highlight 2, support |
| `metric` | `14-stat-ring` | One hero percentage with a ring. Set the ring fill with `--pct` on the circle (`--pct:.62` for 62 %) and the counter with `data-count` | ring + counter |
| `metrics-grid` | `15-stats-radial` (3 counters + radial hub with 4 categories; hub fires automatically after the last counter), `19-bento-metrics` (bento tiles: big score, years + image carousel, two qualities with small animated icons) | Several numbers at once | counter per click |
| `screens` | `16-browser-cards-3` | 3 browser frames: looping MP4 (`video muted loop autoplay`) or tall screenshot with simulated scroll (`img.scroll`, `--dist`, `--dur`) | card per click |
| `gallery` | carousel inside `19-bento-metrics` (`.frames` + `.sq.has-img`) | Square portfolio pieces scrolling in a loop | — |
| `video` | `20-video-feature` | A reel with sound that starts when the slide opens (`video[data-slide-play]`) | — |
| `timeline` | `22-venn-timeline` | Venn of 3 actors + 3-step timeline (challenge / solution / learning) | circle per click, then items |
| `ranking` | `23-ranking-result` | A position result (#N) with a leaderboard; the hero row "drops" into its slot | rows, hero row, punchline |
| `cta` | `24-cta-3` | Closing: repeats the hook question, answers it with 3 principles (one per agenda block, same colours/icons), punchline | panel per click, punchline |
| `closing` | `25-qa-closing` | Q&A + thank-you + presenters | thanks on click |
| `team` | `18-hub-orbit` | A team/hub at the centre with 5 orbiting capabilities | spoke per click |

When the brief says `auto`, pick by content: a single number → `metric`; 3+ numbers →
`metrics-grid`; "before/after" or "X vs Y" → `comparison`; ordered stages → `process`;
screenshots/recordings → `screens`; long sentence that must be read → `statement`.

## Adapting a component

- **Text length is the main risk.** Each component was sized for its copy. If the new copy
  is longer, first shorten it (CP voice favours short lines anyway), then reduce font size by
  one step of the type scale, and only then move boxes. Re-check with a preview.
- **Equal components must occupy equal space** (cards in a row: same width, same top,
  same internal rows — give multi-line fields a `min-height` so pills/buttons align).
- **Counters**: `data-count="94" data-suffix="%"`, `data-prefix="+"`, `data-dec="1"`
  (decimal comma). The visible initial text should be the zero state (`0%`).
- **Colour**: only `var(--token)` colours from `brand-cp.md`. Panels/tiles use the
  `c-blue / c-navy / c-mint / c-sand / c-green / c-sky / c-white` classes.
- **Logo**: every slide ends with `<img class="logo" src="assets/cp-logo-white.png">` on dark
  backgrounds (navy, blue) or `cp-logo-color.png` on light ones (white, surface, mint, sand, sky).
- **Ids must stay unique**: `#threads` (divider-threads) can appear once; canvases use
  classes (`canvas.net`, `canvas.globe`) and can repeat.
- **Media**: reference files as `assets/<name>`; build_deck.py copies them from the client's
  material folder. Prepare them with `scripts/optimize_media.py` first.

## Things the reference deck learned the hard way

- Big `.split` headlines used to clip the last letter; the engine now pads each word box. If a
  heavy glyph still clips, add a trailing space in the text, never remove `overflow:hidden`.
- A screen recording usually includes browser chrome, the OS taskbar and a "sharing your
  screen" banner — crop them (`gif2mp4 --crop`) because the card already draws a browser frame.
- Screenshots are often narrower than the card (e.g. 474 px for a 555 px card) and look soft —
  ask for wider captures if quality matters.
- Two scrolling screenshots side by side look mechanical in sync — give one a negative
  `animation-delay`.
- A ranking must not imply data you don't have: equal-width rows, no proportional bars, unless
  the brief gives the actual values.
