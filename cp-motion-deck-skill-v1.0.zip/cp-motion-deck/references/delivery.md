# Delivery: GitHub-ready folder

The deliverable is a folder that can be dropped into a GitHub repo as-is:

```
<deck-slug>/
├── index.html        # the whole deck (engine + slides)
├── LEEME.txt         # (es) or README-deck.txt (en) — how to present, controls, file list
├── README.md         # one-paragraph repo readme
└── assets/           # only files the deck references (+ CP logos)
```

`build_deck.py` produces exactly this. Also write `CHANGES.md` next to it when updating an
existing deck (what changed per slide) so the client can write the commit message.

## Pushing to the client's repo

1. If a GitHub connector with **write** access to the target repo is available, commit text
   files (`index.html`, `LEEME.txt`, `README.md`) with it. Most connectors only send text —
   images and videos cannot be pushed that way.
2. Otherwise (or for binaries) the client uploads via github.com → **Add file → Upload files**,
   dragging the *contents* of the folder (not the folder itself) so `index.html` sits at the
   repo root. Per-file limit 25 MB.
3. On updates, only changed files need re-uploading — compare against the repo first (the
   connector can read the repo: list `assets/` sizes, compare blob SHAs with
   `git hash-object`) and tell the client exactly which files to upload.
4. To publish as a website: repo → Settings → Pages → Deploy from branch `main` / root.

## Size budget
- Single file ≤ 25 MB (GitHub web upload). Reels: `optimize_media.py video --max-mb 20`.
- If a hosted preview (e.g. claude.ai artifact) is also wanted: each binary ≤ 15 MB.
- Carousel/tile images ≤ ~60 KB each (360 px); full-bleed photos ≤ ~400 KB.

## Delivery summary (always, in chat)
- Link/location of the folder, slide count, total size.
- What came from the brief vs. what you decided (component choices, copy shortened).
- Open items: missing assets, numbers without source, narrative issues (narrative.md).
- QA result and which slides were visually checked.
