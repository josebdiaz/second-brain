# Narrative check (run before building)

A client draft usually arrives as a list of topics. Before mapping slides, check the story.
These are the problems a mentor flagged on the reference deck; check every new brief for them.

1. **Hook before introductions.** Open with the audience's question or tension (pathos),
   not with the presenters. The hook *asks*; it must not answer with lines that a later
   section uses — keep the payoff for that section.
2. **Credibility through the audience's lens (ethos).** Present speakers as people who stood
   where the audience stands, then show the scale of what they do now.
3. **Evidence with sources (logos).** Every number on a slide must come from the brief's
   data table. If a number is missing, ask; do not estimate, round up, or widen its scope
   (e.g. "#3 in the CP ecosystem" must not become "#3 in the world").
4. **Agenda = what the deck actually contains.** Count the real sections; the agenda must
   name exactly those blocks, in that order. Remove agenda items that have no section.
5. **Corporate statements as bridges, not formalities.** If the deck shows the CP purpose,
   connect it explicitly to the agenda (e.g. its three words = the three blocks) — text verbatim.
6. **Close the loop with a call to action.** Before Q&A, repeat the hook question and answer it
   with one principle per block. Each principle must match its block's theme (a "Care" point
   about scale or volume reads wrong — it should be about the people served).
7. **Rhetoric stays in the script.** Ethos/pathos/logos structure the talk; never print the
   theory on slides.

When the brief conflicts with these points, keep the client's content but list the issues and
your proposed fix in the delivery summary — the client decides.

Optional deliverable: speaker notes per slide (who speaks, transition line into the next slide).
