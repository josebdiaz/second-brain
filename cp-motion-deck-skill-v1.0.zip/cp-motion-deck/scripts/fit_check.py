#!/usr/bin/env python3
"""Text-fit check without a browser (fallback when no screenshot tool is available).

Usage: python fit_check.py slides.html|DECK_DIR [--font PATH.ttf] [--margin 1.06]

Measures text with an Arial-metric font (Liberation Sans) scaled by --margin as a proxy
for DM Sans, then reports:
  - words wider than their box (they cannot wrap -> clipped/overflowing), e.g. a long
    word inside an orb or a narrow card;
  - .split headlines that wrap into more lines than their '|' breaks (may hit content below);
  - single-line items (pills, kickers, nowrap) wider than their box.
Box width = nearest inline `width:Npx` (orbs/cards: minus padding), else the space from the
element's `left` to the 80 px right margin. It is a heuristic: confirm flagged slides visually.
"""
import argparse, glob, os, re, sys
from html.parser import HTMLParser
from PIL import ImageFont

CLASS_SIZE = {'d-xxl': 220, 'd-xl': 176, 'd-l': 132, 'd-m': 96, 'd-s': 72, 'h3': 44, 'body': 34,
              'small': 26, 'kicker': 24, 'idx': 56, 'ag-w': 72, 'ag-c': 40, 'cta-h': 48, 'cta-b': 26,
              'spk-nm': 64, 'spk-role': 28, 'spk-st': 22, 'tl-txt': 24, 'lbl': 40, 'sub': 24, 'pill': 30}
BOLD = {'d-xxl', 'd-xl', 'd-l', 'd-m', 'd-s', 'h3', 'idx', 'ag-w', 'cta-h', 'spk-nm', 'lbl', 'num'}
PAD = {'orb': 0.78, 'panel': None, 'spk': None}
VOID = {'img', 'br', 'input', 'meta', 'link', 'source', 'path', 'circle', 'line', 'rect', 'hr'}

def font_for(path, size, bold):
    cands = [path] if path else []
    cands += glob.glob('/usr/share/fonts/**/LiberationSans-%s.ttf' % ('Bold' if bold else 'Regular'), recursive=True)
    cands += glob.glob('/usr/share/fonts/**/DejaVuSans%s.ttf' % ('-Bold' if bold else ''), recursive=True)
    for c in cands:
        if c and os.path.exists(c):
            return ImageFont.truetype(c, max(1, int(size)))
    sys.exit('no TTF font found; pass --font')

class Node:
    def __init__(self, tag, attrs, parent):
        self.tag, self.a, self.parent, self.kids, self.text = tag, dict(attrs), parent, [], ''
        self.cls = set((self.a.get('class') or '').split())
        self.style = self.a.get('style') or ''

class P(HTMLParser):
    def __init__(self):
        super().__init__(); self.root = Node('root', [], None); self.cur = self.root
    def handle_starttag(self, tag, attrs):
        n = Node(tag, attrs, self.cur); self.cur.kids.append(n)
        if tag not in VOID: self.cur = n
    def handle_endtag(self, tag):
        c = self.cur
        while c is not self.root and c.tag != tag: c = c.parent
        if c is not self.root: self.cur = c.parent
    def handle_data(self, d):
        self.cur.text += d
        self.cur.kids.append(d)

def px(style, prop):
    m = re.search(r'(?<![-\w])' + prop + r'\s*:\s*(-?\d+(?:\.\d+)?)px', style)
    return float(m.group(1)) if m else None

def eff_size(n):
    while n:
        v = px(n.style, 'font-size')
        if v: return v
        for c in n.cls:
            if c in CLASS_SIZE: return CLASS_SIZE[c]
        n = n.parent
    return 34

def is_bold(n):
    while n:
        m = re.search(r'font-weight\s*:\s*(\d+)', n.style)
        if m: return int(m.group(1)) >= 600
        if n.cls & BOLD: return True
        n = n.parent
    return False

def box(n):
    left_acc = 0
    m = n
    while m and m.tag != 'section':
        w = px(m.style, 'width')
        if w:
            if 'orb' in m.cls or (m.parent and 'orb' in m.parent.cls): return w * 0.92
            if m.cls & {'panel', 'spk', 'tile', 'rank'}: return w - 80
            return w
        if m.cls & {'orb'}:
            w = px(m.style, 'width')
            if w: return w * 0.92
        l = px(m.style, 'left')
        if l is not None: left_acc += l
        m = m.parent
    return max(200, 1840 - left_acc)

def text_of(n):
    out = []
    for k in n.kids:
        if isinstance(k, str): out.append(k)
        elif k.tag == 'br': out.append('|')
        elif k.tag not in ('svg', 'script', 'style'): out.append(text_of(k))
    return ''.join(out)

def walk(n, f):
    yield n
    for k in n.kids:
        if not isinstance(k, str): yield from walk(k, f)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('src'); ap.add_argument('--font'); ap.add_argument('--margin', type=float, default=1.03)
    a = ap.parse_args()
    src = os.path.join(a.src, 'index.html') if os.path.isdir(a.src) else a.src
    html = open(src, encoding='utf-8').read()
    s = html.find('<div id="stage">'); e = html.find('<div id="wipe"')
    if s >= 0 and e > s: html = html[s:e]
    p = P(); p.feed(html)
    issues = 0; idx = 0
    for sec in [k for k in walk(p.root, None) if k.tag == 'section']:
        idx += 1
        title = sec.a.get('data-title', '')
        for n in walk(sec, None):
            if n is sec or n.tag in ('svg', 'path', 'circle', 'script', 'style'): continue
            own = ''.join(k if isinstance(k, str) else (' ' if k.tag == 'br' else '') for k in n.kids).strip()
            is_split = 'split' in n.cls
            if not own and not is_split: continue
            txt = text_of(n) if is_split else own
            size = eff_size(n); bold = is_bold(n); f = font_for(a.font, size, bold)
            W = box(n)
            ls = -0.02 * size if (is_split or n.cls & BOLD) else 0
            def width(t): return (f.getlength(t) + ls * len(t)) * a.margin
            for w in re.split(r'[\s|]+', txt):
                if w and width(w) > W:
                    print(f'slide {idx:02d} ({title}): word "{w}" is {width(w):.0f}px wide in a {W:.0f}px box ({size:.0f}px text)'); issues += 1
            nowrap = 'nowrap' in n.style or n.cls & {'pill', 'kicker'} or (n.parent and n.parent.cls & {'pill'})
            if nowrap and width(re.sub(r'\s+', ' ', txt).strip()) > W:
                print(f'slide {idx:02d} ({title}): single-line text "{txt.strip()[:40]}" overflows ({width(txt.strip()):.0f}px > {W:.0f}px)'); issues += 1
            if is_split:
                for line in txt.split('|'):
                    words = line.split(); lines = 1; cur = 0; sp = width(' ')
                    for w in words:
                        ww = width(w)
                        if cur and cur + sp + ww > W: lines += 1; cur = ww
                        else: cur = cur + (sp if cur else 0) + ww
                    if lines > 1:
                        print(f'slide {idx:02d} ({title}): headline line "{line.strip()[:40]}" wraps to {lines} lines in {W:.0f}px — add a "|" break, shorten, or reduce size'); issues += 1
    print(f'fit_check: {issues} potential issue(s) · proxy font Arial-metrics ×{a.margin}')

if __name__ == '__main__':
    main()
