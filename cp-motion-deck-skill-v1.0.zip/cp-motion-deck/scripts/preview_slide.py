#!/usr/bin/env python3
"""Make a self-contained preview of ONE slide for visual QA (screenshot tools that
cannot load relative files or web fonts).

Usage: python preview_slide.py DECK_DIR (or DECK_DIR/index.html) --slide N [--final] --out preview.html
  --slide N   1-based slide number
  --final     jump straight to the last build step with transitions off (layout check)
              omit it to watch the real timing from the slide's first step
Images (and videos < 6 MB) are inlined as data: URIs; the Google Fonts link is removed
so the preview falls back to Arial — widths differ slightly from DM Sans.
"""
import argparse, base64, mimetypes, os, re

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('deck'); ap.add_argument('--slide', type=int, required=True)
    ap.add_argument('--final', action='store_true'); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    if os.path.isdir(a.deck):
        a.deck = os.path.join(a.deck, 'index.html')
    base = os.path.dirname(os.path.abspath(a.deck))
    s = open(a.deck, encoding='utf-8').read()
    s = re.sub(r'<link rel="stylesheet"[^>]*>', '', s)

    def inline(m):
        rel = m.group(1); f = os.path.join(base, rel)
        if not os.path.exists(f):
            return m.group(0)
        if f.endswith('.mp4') and os.path.getsize(f) > 6 * 1048576:
            return m.group(0)
        mime = mimetypes.guess_type(f)[0] or 'application/octet-stream'
        return 'data:%s;base64,%s' % (mime, base64.b64encode(open(f, 'rb').read()).decode())
    s = re.sub(r'(assets/[\w\-. ]+\.\w+)', inline, s)

    s = s.replace('let cur=0,step=0,busy=false;', f'let cur={a.slide-1},step=0,busy=false;')
    s = s.replace('</style>', '#hint{display:none}</style>', 1)
    if a.final:
        s = s.replace('</style>', '*{transition:none!important}.split .ch{transform:none!important}</style>', 1)
        s = s.replace('  show(cur,0);\n', '  show(cur,0);setTimeout(()=>{step=slides[cur]._max;apply(slides[cur],step);hud()},50);\n', 1)
    open(a.out, 'w', encoding='utf-8').write(s)
    print(a.out)

if __name__ == '__main__':
    main()
