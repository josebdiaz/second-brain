#!/usr/bin/env python3
"""Pre-delivery QA for a CP motion deck folder (index.html + assets/).

Usage: python qa_check.py DECK_DIR
Exit code 1 if any ERROR is found. WARN items should be reviewed but do not block.
"""
import os, re, shutil, subprocess, sys, tempfile

PALETTE = {'#002a46', '#004272', '#0068ff', '#ffffff', '#fff', '#edf2f7', '#dde9f0', '#231f20',
           '#00c68b', '#ff4c4c', '#aae3cd', '#abc2db', '#e5cfbf', '#f4f6f8'}
PLACEHOLDER = re.compile(r'Placeholder|\[Por completar\]|por confirmar|Lorem ipsum|\[\[.*?\]\]', re.I)
PLACEHOLDER_CS = re.compile(r'(?<![\w-])XX%?(?![\w-])|\bTBD\b|\bTODO\b')  # case-sensitive: Spanish 'todo' is a normal word
GITHUB_WEB_LIMIT = 25 * 1024 * 1024   # GitHub "Upload files" per-file limit
HOSTED_LIMIT = 15 * 1024 * 1024       # claude.ai artifact binary limit (hosted preview)

def main():
    d = sys.argv[1] if len(sys.argv) > 1 else '.'
    p = os.path.join(d, 'index.html')
    if not os.path.exists(p):
        sys.exit(f'ERROR: {p} not found')
    html = open(p, encoding='utf-8').read()
    errs, warns = [], []

    a = html.find('<div id="stage">'); b = html.find('<div id="wipe"')
    slides_html = html[a:b] if a >= 0 and b > a else html
    sections = re.findall(r'(<section class="slide[^>]*>)(.*?)</section>', slides_html, re.S)
    if not sections:
        errs.append('no slides found')

    for i, (open_tag, body) in enumerate(sections, 1):
        t = re.search(r'data-title="([^"]*)"', open_tag)
        label = f'slide {i:02d} ({t.group(1) if t else "no title"})'
        if not t:
            warns.append(f'{label}: missing data-title (used by the jump slider tooltip)')
        steps = sorted({int(x) for x in re.findall(r'data-s="(\d+)"', body)})
        if not steps:
            warns.append(f'{label}: no build steps (data-s) — slide is static')
        elif steps[0] != 0 or steps != list(range(steps[0], steps[-1] + 1)):
            warns.append(f'{label}: build steps not contiguous from 0: {steps}')
        for m in re.finditer(r'class="[^"]*\bsplit\b[^"]*"[^>]*>(.*?)</h[1-6]>', body, re.S):
            if '<' in m.group(1):
                warns.append(f'{label}: .split headline contains HTML tags (split uses plain text; tags are dropped)')
        if not re.search(r'class="logo"', body) and 'cp-logo' not in body:
            warns.append(f'{label}: no CP logo on slide')

    # placeholders / forbidden wording
    for m in list(PLACEHOLDER.finditer(slides_html)) + list(PLACEHOLDER_CS.finditer(slides_html)):
        ctx = re.sub(r'\s+', ' ', slides_html[max(0, m.start()-40):m.end()+40])
        errs.append(f'placeholder text left: "…{ctx}…"')
    if re.search(r'\bCLab\b', slides_html):
        errs.append('forbidden acronym "CLab" — always write "Content Lab"')

    # palette
    for c in sorted({c.lower() for c in re.findall(r'#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b', slides_html)}):
        if c not in PALETTE:
            warns.append(f'off-palette colour in slides: {c} (use the var(--token) colours)')
    if re.search(r'color:\s*#000\b|color:\s*#000000\b|color:\s*black\b', slides_html, re.I):
        errs.append('pure black text — use var(--ink) #231F20 or var(--navy)')

    # tiny text
    for px in re.findall(r'font-size:\s*(\d+(?:\.\d+)?)px', slides_html):
        if float(px) < 14:
            errs.append(f'text smaller than 14px found (font-size:{px}px)')

    # assets
    refs = sorted(set(re.findall(r'assets/([\w\-. ]+\.\w+)', html)))
    total = os.path.getsize(p)
    for r in refs:
        f = os.path.join(d, 'assets', r)
        if not os.path.exists(f):
            errs.append(f'missing asset: assets/{r}')
            continue
        sz = os.path.getsize(f); total += sz
        if sz > GITHUB_WEB_LIMIT:
            errs.append(f'assets/{r} is {sz/1048576:.1f} MB (> 25 MB GitHub web upload limit) — compress with optimize_media.py video')
        elif sz > HOSTED_LIMIT:
            warns.append(f'assets/{r} is {sz/1048576:.1f} MB (> 15 MB: too big for a hosted claude.ai preview; fine for GitHub/zip)')
        if r.lower().endswith(('.jpg', '.jpeg', '.png')) and sz > 1.5 * 1048576:
            warns.append(f'assets/{r} is {sz/1048576:.1f} MB — resize with optimize_media.py image')
        if r.lower().endswith('.gif'):
            warns.append(f'assets/{r} is a GIF — convert with optimize_media.py gif2mp4 (smaller, smoother)')
    unused = sorted(set(os.listdir(os.path.join(d, 'assets'))) - set(refs)) if os.path.isdir(os.path.join(d, 'assets')) else []
    if unused:
        warns.append('unused files in assets/: ' + ', '.join(unused))

    # JS syntax
    node = shutil.which('node')
    s = html.find('<script>'); e = html.find('</script>', s)
    if node and s >= 0:
        with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False, encoding='utf-8') as tf:
            tf.write(html[s+8:e])
        r = subprocess.run([node, '--check', tf.name], capture_output=True, text=True)
        os.unlink(tf.name)
        if r.returncode:
            errs.append('engine JS syntax error: ' + r.stderr.strip().splitlines()[-1])
    elif not node:
        warns.append('node not available — JS syntax not checked')

    print(f'QA · {len(sections)} slides · {len(refs)} assets · total {total/1048576:.1f} MB')
    for x in errs:
        print('ERROR ', x)
    for x in warns:
        print('WARN  ', x)
    if not errs and not warns:
        print('OK — no issues found')
    sys.exit(1 if errs else 0)

if __name__ == '__main__':
    main()
